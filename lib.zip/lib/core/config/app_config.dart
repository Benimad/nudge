/// Nudge app — API configuration
/// Keep this file out of public repositories.
class AppConfig {
  // Gemini API key — Gemma 4 26B model
  static const String geminiApiKey =
      'AQ.Ab8RN6JAzNUbnHU3KUGUdVKCQSkAi1ZjF1yw2VC1Xiupn2rjmQ';

  // Model: Gemma 4 26B A4B Instruction-tuned
  // Activates ~4B params per inference — fast, efficient, high-quality
  static const String geminiModel = 'gemma-4-26b-a4b-it';
}
