import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // Brand colors from Master Prompt
  static const Color primaryColor = Color(0xFF7F77DD); // Purple
  static const Color successColor = Color(0xFF1D9E75); // Mint Green
  static const Color warningColor = Color(0xFFEF9F27); // Amber
  static const Color backgroundColor = Color(0xFFFAFAF9);
  static const Color cardColor = Colors.white;
  static const Color textColor = Color(0xFF2D2D2D);

  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primaryColor,
        primary: primaryColor,
        secondary: successColor,
        tertiary: warningColor,
        surface: cardColor,
        onSurface: textColor,
        brightness: Brightness.light,
      ),
      scaffoldBackgroundColor: backgroundColor,
      textTheme: GoogleFonts.interTextTheme().copyWith(
        displayLarge: const TextStyle(fontWeight: FontWeight.w600, fontSize: 24, color: textColor, letterSpacing: -0.5),
        displayMedium: const TextStyle(fontWeight: FontWeight.w600, fontSize: 22, color: textColor, letterSpacing: -0.5),
        displaySmall: const TextStyle(fontWeight: FontWeight.w600, fontSize: 20, color: textColor, letterSpacing: -0.5),
        headlineMedium: const TextStyle(fontWeight: FontWeight.w600, fontSize: 22, color: textColor, letterSpacing: -0.3),
        headlineSmall: const TextStyle(fontWeight: FontWeight.w600, fontSize: 20, color: textColor, letterSpacing: -0.3),
        titleLarge: const TextStyle(fontWeight: FontWeight.w600, fontSize: 22, color: textColor, letterSpacing: -0.3),
        bodyLarge: const TextStyle(fontWeight: FontWeight.w400, fontSize: 16, color: textColor, letterSpacing: 0.1),
        bodyMedium: const TextStyle(fontWeight: FontWeight.w400, fontSize: 16, color: textColor, letterSpacing: 0.1),
        bodySmall: const TextStyle(fontWeight: FontWeight.w400, fontSize: 14, color: Colors.grey),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        color: cardColor,
        margin: const EdgeInsets.only(bottom: 12),
      ),
      appBarTheme: const AppBarTheme(
        centerTitle: false,
        elevation: 0,
        backgroundColor: backgroundColor,
        foregroundColor: textColor,
        titleTextStyle: TextStyle(fontWeight: FontWeight.w500, fontSize: 22, color: textColor, fontFamily: 'Inter'),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryColor,
          foregroundColor: Colors.white,
          minimumSize: const Size(double.infinity, 56),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          elevation: 0,
          textStyle: const TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: primaryColor,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
        ),
      ),
    );
  }

  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primaryColor,
        brightness: Brightness.dark,
      ),
      textTheme: GoogleFonts.interTextTheme(ThemeData.dark().textTheme),
    );
  }

  static const List<Color> habitColors = [
    primaryColor,
    successColor,
    warningColor,
    Color(0xFF68B0AB), // Teal
    Color(0xFFB8A5D8), // Soft purple
    Color(0xFFF4A261), // Warm orange
    Color(0xFFE76F51), // Coral
    Color(0xFFD88373), // Dusty rose
  ];

  // Premium UI additions
  static const LinearGradient brandGradient = LinearGradient(
    colors: [primaryColor, Color(0xFF6B62D0)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient textGradient = LinearGradient(
    colors: [Color(0xFF5D55BA), Color(0xFF8B84D3)],
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );
}
