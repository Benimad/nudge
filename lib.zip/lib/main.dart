import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'core/theme/app_theme.dart';
import 'core/database/database_helper.dart';
import 'core/notifications/notification_service.dart';
import 'core/services/firebase_service.dart';
import 'features/settings/services/subscription_service.dart';
import 'features/onboarding/screens/welcome_screen.dart';
import 'features/onboarding/screens/goals_screen.dart';
import 'features/onboarding/screens/reminder_setup_screen.dart';
import 'features/habits/screens/home_screen.dart';
import 'features/paralysis_mode/screens/paralysis_mode_screen.dart';
import 'features/body_doubling/screens/body_doubling_screen.dart';
import 'features/ai_coach/screens/ai_coach_screen.dart';
import 'features/stats/screens/stats_screen.dart';
import 'features/settings/screens/settings_screen.dart';
import 'features/settings/screens/paywall_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Firebase
  final firebaseInitialized = await FirebaseService.initialize();
  if (!firebaseInitialized) {
    debugPrint('⚠️ App running without Firebase - some features may be limited');
  }

  // Initialize Database
  try {
    await DatabaseHelper.instance.database;
    debugPrint('✅ Database initialized');
  } catch (e) {
    debugPrint('❌ Database init error: $e');
  }

  // Initialize RevenueCat
  try {
    await SubscriptionService.init();
    debugPrint('✅ RevenueCat initialized');
  } catch (e) {
    debugPrint('⚠️ RevenueCat init error: $e');
  }

  // Initialize Notifications
  try {
    await NotificationService().init();
    debugPrint('✅ Notifications initialized');
  } catch (e) {
    debugPrint('⚠️ Notification init error: $e');
  }

  runApp(const NudgeApp());
}

class NudgeApp extends StatelessWidget {
  const NudgeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Nudge',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.system,
      navigatorKey: Get.key,
      getPages: [
        GetPage(name: '/', page: () => const WelcomeScreen()),
        GetPage(name: '/onboarding/welcome', page: () => const WelcomeScreen()),
        GetPage(name: '/onboarding/goals', page: () => const GoalsScreen()),
        GetPage(name: '/onboarding/reminders', page: () => const ReminderSetupScreen()),
        GetPage(name: '/home', page: () => const HomeScreen()),
        GetPage(name: '/paralysis-mode', page: () => const ParalysisModeScreen()),
        GetPage(name: '/body-doubling', page: () => const BodyDoublingScreen()),
        GetPage(name: '/ai-coach', page: () => const AiCoachScreen()),
        GetPage(name: '/stats', page: () => const StatsScreen()),
        GetPage(name: '/settings', page: () => const SettingsScreen()),
        GetPage(name: '/paywall', page: () => const PaywallScreen()),
      ],
    );
  }
}
