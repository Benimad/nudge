import 'package:get/get.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import '../services/ai_service.dart';

class ChatController extends GetxController {
  final AiCoachService _aiService = AiCoachService();
  final stt.SpeechToText _speech = stt.SpeechToText();
  
  final messages = <ChatMessage>[].obs;
  final isLoading = false.obs;
  final isListening = false.obs;
  bool _speechAvailable = false;

  final List<String> suggestedPrompts = [
    "Why do I keep forgetting my habits?",
    "Help me start my work block",
    "I missed 3 days — what now?",
    "Break down my hardest task",
    "I'm feeling overwhelmed",
  ];

  @override
  void onInit() {
    super.onInit();
    _loadHistory();
    _initSpeech();
  }

  Future<void> _initSpeech() async {
    _speechAvailable = await _speech.initialize(
      onError: (error) => {},
      onStatus: (status) => {},
    );
  }

  void _loadHistory() {
    // Load last 50 messages from local storage (simplified for now)
    // In production, load from SQLite
  }

  Future<void> sendMessage(String text) async {
    if (text.trim().isEmpty) return;

    // Add user message
    messages.add(ChatMessage(text: text, isUser: true));
    isLoading.value = true;

    try {
      // Get user context for personalized response
      final context = await _getUserContext();
      
      // Get AI response
      final response = await _aiService.getResponse(text, context: context);

      // Simulate natural typing delay (150-300ms per word)
      final wordCount = response.split(' ').length;
      final delay = (wordCount * 50).clamp(300, 2000);
      await Future.delayed(Duration(milliseconds: delay));

      messages.add(ChatMessage(text: response, isUser: false));
    } catch (e) {
      messages.add(ChatMessage(
        text: "I'm here for you. Let me think about this differently... ${_aiService.getResponse('help')}",
        isUser: false,
      ));
    } finally {
      isLoading.value = false;
    }
  }

  Future<Map<String, dynamic>> _getUserContext() async {
    // In production, load from SharedPreferences and SQLite
    return {
      'time_of_day': DateTime.now().hour < 12 ? 'morning' : DateTime.now().hour < 17 ? 'afternoon' : 'evening',
      'mood': _aiService.moodInsight,
    };
  }

  /// Get task breakdown for paralysis mode
  List<String> getTaskBreakdown(String taskName) {
    return _aiService.getTaskBreakdown(taskName);
  }

  /// Get weekly insight
  String getWeeklyInsight(Map<String, dynamic> stats) {
    return _aiService.getWeeklyInsight(stats);
  }

  Future<void> startVoiceInput() async {
    if (!_speechAvailable) {
      Get.snackbar(
        'Voice Input Unavailable',
        'Speech recognition is not available on this device',
        snackPosition: SnackPosition.BOTTOM,
      );
      return;
    }

    if (isListening.value) {
      await _speech.stop();
      isListening.value = false;
      return;
    }

    isListening.value = true;
    await _speech.listen(
      onResult: (result) {
        if (result.finalResult && result.recognizedWords.isNotEmpty) {
          sendMessage(result.recognizedWords);
          isListening.value = false;
        }
      },
      listenOptions: stt.SpeechListenOptions(
        listenMode: stt.ListenMode.confirmation,
        cancelOnError: true,
        partialResults: false,
        onDevice: true,
        listenFor: const Duration(seconds: 30),
        pauseFor: const Duration(seconds: 3),
      ),
    );
  }
}

class ChatMessage {
  final String text;
  final bool isUser;
  final DateTime timestamp;

  ChatMessage({
    required this.text,
    required this.isUser,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();
}