import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ClaudeService {
  static const String _baseUrl = 'https://api.anthropic.com/v1/messages';
  
  // In production, this should come from a secure backend or environment
  static const String _apiKey = 'YOUR_CLAUDE_API_KEY';

  Future<String> sendMessage({
    required List<Map<String, String>> history,
    required String userMessage,
    required Map<String, dynamic> userContext,
  }) async {
    try {
      // Build system prompt with user context
      final systemPrompt = _buildSystemPrompt(userContext);

      // Build messages array
      final messages = <Map<String, dynamic>>[
        {'role': 'user', 'content': userMessage},
      ];

      final response = await http.post(
        Uri.parse(_baseUrl),
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': _apiKey,
          'anthropic-version': '2023-06-01',
        },
        body: jsonEncode({
          'model': 'claude-3-sonnet-20240229',
          'max_tokens': 1024,
          'system': systemPrompt,
          'messages': messages,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['content'][0]['text'];
      } else {
        throw Exception('API error: ${response.statusCode}');
      }
    } catch (e) {
      // Return static tips when offline or API fails
      return _getOfflineTips();
    }
  }

  String _buildSystemPrompt(Map<String, dynamic> context) {
    return '''You are a gentle, knowledgeable ADHD coach inside the Nudge app. You understand ADHD deeply — executive dysfunction, rejection sensitive dysphoria, time blindness, hyperfocus, and emotional dysregulation.

User context: ${jsonEncode(context)}

Rules:
- Never use the words: just, simply, easy, should
- Never say 'have you tried...' — give direct suggestions
- Always validate before advising
- Keep responses under 3 sentences unless user asks for more
- If user seems in crisis → gently suggest professional help
- Celebrate any win, no matter how small
- Never shame missed habits
- Speak like a warm friend who happens to know ADHD deeply''';
  }

  String _getOfflineTips() {
    final tips = [
      "I'm offline right now, but here's a quick tip: Break your current task into tiny steps. Even starting with 2 minutes counts as a win.",
      "Can't connect right now! Remember: progress isn't linear. What matters is that you're trying, and that's already huge.",
      "Offline mode activated! Quick tip: Try the 2-minute rule — if a task takes less than 2 minutes, do it immediately. You've got this!",
      "I'm offline, but you're doing great! Here's a reminder: perfection isn't the goal. Done is better than perfect.",
    ];
    return tips[DateTime.now().millisecondsSinceEpoch % tips.length];
  }

  Future<Map<String, dynamic>> getUserContext() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      'brain_type': prefs.getString('brain_type') ?? 'Not specified',
      'goals': prefs.getString('user_goals') ?? 'Not set',
      'dopamine_points': prefs.getInt('dopamine_points') ?? 0,
    };
  }
}