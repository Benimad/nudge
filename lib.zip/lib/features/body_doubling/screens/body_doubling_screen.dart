import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/body_doubling_controller.dart';
import '../../../core/theme/app_theme.dart';

class BodyDoublingScreen extends StatelessWidget {
  const BodyDoublingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(BodyDoublingController());

    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      appBar: AppBar(
        title: const Text('Body Doubling', style: TextStyle(fontWeight: FontWeight.w500)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Obx(() {
        if (!controller.isSessionActive.value) {
          return _buildSetupView(context, controller);
        }
        return _buildActiveSessionView(context, controller);
      }),
    );
  }

  Widget _buildSetupView(BuildContext context, BodyDoublingController controller) {
    final TextEditingController taskController = TextEditingController();
    int selectedMinutes = 25;

    return Padding(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Start a focus session',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w500),
          ),
          const SizedBox(height: 8),
          const Text(
            'Working with others helps ADHD brains stay on track.',
            style: TextStyle(color: Colors.grey),
          ),
          const SizedBox(height: 32),
          const Text('What are you working on?', style: TextStyle(fontWeight: FontWeight.w500)),
          const SizedBox(height: 12),
          TextField(
            controller: taskController,
            decoration: InputDecoration(
              hintText: 'e.g. Cleaning the kitchen',
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 32),
          const Text('Session length', style: TextStyle(fontWeight: FontWeight.w500)),
          const SizedBox(height: 12),
          StatefulBuilder(builder: (context, setState) {
            return Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [15, 25, 45, 60].map((mins) {
                final isSelected = selectedMinutes == mins;
                return GestureDetector(
                  onTap: () => setState(() => selectedMinutes = mins),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: isSelected ? AppTheme.primaryColor : Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isSelected ? AppTheme.primaryColor : Colors.grey.shade300,
                      ),
                    ),
                    child: Text(
                      '$mins',
                      style: TextStyle(
                        color: isSelected ? Colors.white : Colors.black87,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                );
              }).toList(),
            );
          }),
          const Spacer(),
          ElevatedButton(
            onPressed: () {
              if (taskController.text.isNotEmpty) {
                controller.startSession(taskController.text, selectedMinutes);
              }
            },
            child: const Text('Start session'),
          ),
        ],
      ),
    );
  }

  Widget _buildActiveSessionView(BuildContext context, BodyDoublingController controller) {
    return Stack(
      children: [
        Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Timer Display
              Center(
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox(
                      width: 220,
                      height: 220,
                      child: CircularProgressIndicator(
                        value: 1 - controller.progress,
                        strokeWidth: 6,
                        backgroundColor: Colors.grey.shade200,
                        valueColor: const AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),
                      ),
                    ),
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          controller.formattedTime,
                          style: const TextStyle(
                            fontSize: 48,
                            fontWeight: FontWeight.w500,
                            fontFamily: 'monospace',
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          controller.taskName.value,
                          style: const TextStyle(color: Colors.grey),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 48),
              
              // Community Count
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.grey.shade200),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.people_outline, size: 16, color: AppTheme.primaryColor),
                    const SizedBox(width: 8),
                    Text(
                      '${controller.communityCount.value} people working right now',
                      style: const TextStyle(fontSize: 13, color: Color(0xFF2D2D2D)),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 48),
              
              // Stats
              Row(
                children: [
                  _buildStatCard('Today', '${controller.sessionsCompletedToday.value} sessions'),
                  const SizedBox(width: 12),
                  _buildStatCard('Week', '${controller.totalFocusMinutesWeek.value} mins'),
                ],
              ),
              const Spacer(),
              
              // Controls
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => controller.pauseResumeSession(),
                      child: Text(
                        controller.isSessionActive.value ? 'Pause' : 'Resume',
                        style: const TextStyle(color: Colors.grey, fontWeight: FontWeight.w500),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => _showEndConfirmation(context, controller),
                      style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primaryColor),
                      child: const Text('End session'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        
        // AI Encouragement Bubbles
        Obx(() => controller.showEncouragement.value
            ? Positioned(
                bottom: 120,
                left: 24,
                right: 24,
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEEEDFE),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppTheme.primaryColor.withValues(alpha: 0.3)),
                  ),
                  child: Text(
                    controller.currentEncouragement.value,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: AppTheme.primaryColor, fontWeight: FontWeight.w500),
                  ),
                ),
              )
            : const SizedBox.shrink()),
      ],
    );
  }

  Widget _buildStatCard(String label, String value) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
            const SizedBox(height: 4),
            Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }

  void _showEndConfirmation(BuildContext context, BodyDoublingController controller) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('End session?'),
        content: const Text('You\'re doing great. Are you sure you want to stop now?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Keep going', style: TextStyle(color: AppTheme.primaryColor)),
          ),
          TextButton(
            onPressed: () {
              controller.endSession();
              Navigator.pop(context);
            },
            child: const Text('End now', style: TextStyle(color: Colors.grey)),
          ),
        ],
      ),
    );
  }
}
