import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../widgets/breathing_circle.dart';
import '../../habits/controllers/home_controller.dart';
import '../../habits/models/habit_model.dart';
import '../../ai_coach/services/ai_service.dart';

class ParalysisModeScreen extends StatefulWidget {
  const ParalysisModeScreen({super.key});

  @override
  State<ParalysisModeScreen> createState() => _ParalysisModeScreenState();
}

class _ParalysisModeScreenState extends State<ParalysisModeScreen> {
  bool _showBreathing = false;
  List<String>? _microSteps;
  bool _isLoadingAi = false;
  HabitModel? _selectedHabit;

  void _startBreathing() {
    setState(() => _showBreathing = true);
  }

  void _finishBreathing() {
    setState(() => _showBreathing = false);
  }

  Future<void> _breakdownTask(HabitModel habit) async {
    setState(() {
      _isLoadingAi = true;
      _selectedHabit = habit;
    });

    // Use on-device AI for task breakdown - no API call, works offline
    final aiService = AiCoachService();
    await Future.delayed(const Duration(milliseconds: 500)); // Instant response
    
    setState(() {
      _microSteps = aiService.getTaskBreakdown(habit.name);
      _isLoadingAi = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAF9),
      appBar: AppBar(
        title: const Text('Paralysis Mode', style: TextStyle(color: Color(0xFFEF9F27))),
        leading: const BackButton(),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const _PulsingAmberHeader(),
            const SizedBox(height: 24),
            _buildAiBubble("I notice you've been inactive for a while. Want me to break your task into micro-steps?"),
            const SizedBox(height: 48),
            if (_showBreathing)
              Center(child: BreathingCircle(onComplete: _finishBreathing))
            else if (_microSteps != null)
              _buildMicroStepsList()
            else if (_isLoadingAi)
              const Center(child: CircularProgressIndicator(color: Color(0xFF7F77DD)))
            else
              _buildOptions(),
          ],
        ),
      ),
    );
  }

  Widget _buildAiBubble(String text) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        color: Color(0xFF7F77DD),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(16),
          topRight: Radius.circular(16),
          bottomRight: Radius.circular(16),
        ),
      ),
      child: Text(
        text,
        style: const TextStyle(color: Colors.white, fontSize: 16),
      ),
    );
  }

  Widget _buildOptions() {
    return Column(
      children: [
        ElevatedButton(
          onPressed: () => _showTaskSelector(),
          style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF7F77DD)),
          child: const Text('Yes, help me start'),
        ),
        const SizedBox(height: 12),
        OutlinedButton(
          onPressed: _startBreathing,
          style: OutlinedButton.styleFrom(
            minimumSize: const Size(double.infinity, 56),
            side: const BorderSide(color: Color(0xFF7F77DD)),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          ),
          child: const Text('I need to calm down first', style: TextStyle(color: Color(0xFF7F77DD))),
        ),
      ],
    );
  }

  Widget _buildMicroStepsList() {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Micro-steps for ${_selectedHabit?.name}:', style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          ..._microSteps!.map((step) => Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: ListTile(
              leading: const Icon(Icons.timer_outlined, color: Color(0xFF7F77DD)),
              title: Text(step),
              trailing: Checkbox(
                value: false,
                onChanged: null,
                activeColor: const Color(0xFF1D9E75),
              ),
            ),
          )),
        ],
      ),
    );
  }

  void _showTaskSelector() {
    final habits = Get.find<HomeController>().habits;
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (context) => Container(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Which habit are you stuck on?', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            ...habits.map((h) => ListTile(
              title: Text(h.name),
              onTap: () {
                Navigator.pop(context);
                _breakdownTask(h);
              },
            )),
          ],
        ),
      ),
    );
  }
}

class _PulsingAmberHeader extends StatefulWidget {
  const _PulsingAmberHeader();

  @override
  State<_PulsingAmberHeader> createState() => _PulsingAmberHeaderState();
}

class _PulsingAmberHeaderState extends State<_PulsingAmberHeader> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        FadeTransition(
          opacity: Tween<double>(begin: 0.3, end: 1.0).animate(_controller),
          child: Container(width: 12, height: 12, decoration: const BoxDecoration(color: Color(0xFFEF9F27), shape: BoxShape.circle)),
        ),
        const SizedBox(width: 12),
        const Text('Stuck? That\'s okay.', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w500, color: Color(0xFF2D2D2D))),
      ],
    );
  }
}
