import 'package:flutter/material.dart';

class BreathingCircle extends StatefulWidget {
  final VoidCallback onComplete;

  const BreathingCircle({super.key, required this.onComplete});

  @override
  State<BreathingCircle> createState() => _BreathingCircleState();
}

class _BreathingCircleState extends State<BreathingCircle>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  int _cyclesCompleted = 0;
  final int _targetCycles = 3;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            final scale = 0.6 + (_controller.value * 0.4);
            return Container(
              width: 200 * scale,
              height: 200 * scale,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF7F77DD).withValues(alpha: 0.2),
                border: Border.all(
                  color: const Color(0xFF7F77DD).withValues(alpha: 0.5),
                  width: 3,
                ),
              ),
              child: Center(
                child: Text(
                  _controller.value < 0.5 ? 'Breathe in...' : 'Breathe out...',
                  style: const TextStyle(
                    fontSize: 18,
                    color: Color(0xFF7F77DD),
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 40),
        TextButton(
          onPressed: () {
            _cyclesCompleted++;
            if (_cyclesCompleted >= _targetCycles) {
              widget.onComplete();
            }
          },
          child: const Text(
            'Done',
            style: TextStyle(
              color: Color(0xFF7F77DD),
              fontWeight: FontWeight.w500,
              fontSize: 16,
            ),
          ),
        ),
      ],
    );
  }
}
