import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../controllers/home_controller.dart';
import '../widgets/habit_list_item.dart';
import '../widgets/progress_header.dart';
import '../widgets/add_habit_sheet.dart';
import '../../../core/theme/app_theme.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final HomeController controller = Get.put(HomeController());

    return Scaffold(
      backgroundColor: const Color(0xFFFAFAF9),
      body: SafeArea(
        child: Column(
          children: [
            const ProgressHeader(),
            
            Obx(() => controller.showParalysisBanner.value
                ? _buildParalysisBanner(context)
                : const SizedBox.shrink()),

            Expanded(
              child: Obx(() {
                if (controller.isLoading.value) {
                  return const Center(child: CircularProgressIndicator(color: Color(0xFF7F77DD)));
                }

                if (controller.habits.isEmpty) {
                  return _buildEmptyState(context);
                }

                return RepaintBoundary(
                  child: ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    itemCount: controller.habits.length,
                    itemBuilder: (context, index) {
                      return HabitListItem(habit: controller.habits[index]);
                    },
                  ),
                );
              }),
            ),
          ],
        ),
      ),
      extendBody: true, // Needed for floating nav bar
      floatingActionButton: Padding(
        padding: const EdgeInsets.only(bottom: 80.0), // Move FAB up slightly
        child: FloatingActionButton(
          onPressed: () => _showAddHabitSheet(context),
          backgroundColor: AppTheme.primaryColor,
          elevation: 4,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)), // Squircle
          child: const Icon(Icons.add, color: Colors.white, size: 28),
        ),
      ),
      bottomNavigationBar: _buildFloatingBottomNav(context),
    );
  }

  Widget _buildParalysisBanner(BuildContext context) {
    return GestureDetector(
      onTap: () => Get.toNamed('/paralysis-mode'),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: const Border(left: BorderSide(color: Color(0xFFEF9F27), width: 4)),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFEF9F27).withValues(alpha: 0.1),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            const _PulsingDot(),
            const SizedBox(width: 12),
            const Expanded(
              child: Text(
                'Feeling stuck? Let me help',
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  color: Color(0xFF2D2D2D),
                ),
              ),
            ),
            const Icon(Icons.arrow_forward_ios, size: 14, color: Color(0xFFEF9F27)),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.spa_outlined, size: 64, color: Colors.grey.shade300),
          const SizedBox(height: 16),
          const Text(
            'Add your first habit',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, color: Color(0xFF2D2D2D)),
          ),
          const SizedBox(height: 8),
          const Text(
            'Start with just one small step',
            style: TextStyle(color: Colors.grey),
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: () => _showAddHabitSheet(context),
            style: ElevatedButton.styleFrom(
              minimumSize: const Size(160, 48),
            ),
            child: const Text('Add habit'),
          ),
        ],
      ),
    );
  }

  Widget _buildFloatingBottomNav(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(24, 0, 24, 24),
      height: 64,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(32),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primaryColor.withValues(alpha: 0.1),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _NavBarItem(icon: Icons.home_filled, label: 'Home', index: 0, isSelected: true),
          _NavBarItem(icon: Icons.bar_chart_rounded, label: 'Stats', index: 1, isSelected: false),
          _NavBarItem(icon: Icons.psychology_rounded, label: 'Coach', index: 2, isSelected: false),
          _NavBarItem(icon: Icons.people_alt_rounded, label: 'Focus', index: 3, isSelected: false),
          _NavBarItem(icon: Icons.settings_rounded, label: 'Settings', index: 4, isSelected: false),
        ],
      ),
    ).animate().slideY(begin: 1, end: 0, duration: 600.ms, curve: Curves.easeOutBack);
  }

  void _onNavTap(int index) {
    if (index == 1) Get.toNamed('/stats');
    if (index == 2) Get.toNamed('/ai-coach');
    if (index == 3) Get.toNamed('/body-doubling');
    if (index == 4) Get.toNamed('/settings');
  }

  void _showAddHabitSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => const AddHabitSheet(),
    );
  }
}

class _PulsingDot extends StatefulWidget {
  const _PulsingDot();

  @override
  State<_PulsingDot> createState() => _PulsingDotState();
}

class _PulsingDotState extends State<_PulsingDot> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: Tween<double>(begin: 0.3, end: 1.0).animate(_controller),
      child: Container(
        width: 8,
        height: 8,
        decoration: const BoxDecoration(
          color: Color(0xFFEF9F27),
          shape: BoxShape.circle,
        ),
      ),
    );
  }
}

class _NavBarItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final int index;
  final bool isSelected;

  const _NavBarItem({
    required this.icon,
    required this.label,
    required this.index,
    required this.isSelected,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (index == 1) Get.toNamed('/stats');
        if (index == 2) Get.toNamed('/ai-coach');
        if (index == 3) Get.toNamed('/body-doubling');
        if (index == 4) Get.toNamed('/settings');
      },
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOutBack,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.primaryColor.withValues(alpha: 0.1) : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: isSelected ? AppTheme.primaryColor : Colors.grey.shade400,
              size: 24,
            ),
            if (isSelected) ...[
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  color: AppTheme.primaryColor,
                  fontWeight: FontWeight.w600,
                  fontSize: 13,
                ),
              ).animate().fadeIn().slideX(begin: 0.2, end: 0),
            ]
          ],
        ),
      ),
    );
  }
}
