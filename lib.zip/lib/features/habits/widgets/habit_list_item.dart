import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../models/habit_model.dart';
import '../controllers/home_controller.dart';
import '../../../core/theme/app_theme.dart';

class HabitListItem extends StatelessWidget {
  final HabitModel habit;

  const HabitListItem({super.key, required this.habit});

  @override
  Widget build(BuildContext context) {
    final HomeController controller = Get.find<HomeController>();

    // Using GetBuilder to track a reactive 'pressed' state if we wanted, 
    // but a simple TweenAnimationBuilder on tap is easier.
    final RxBool isPressed = false.obs;

    return RepaintBoundary(
      child: Obx(() {
        final bool isCompleted = controller.isCompleted(habit.id);
        final Color habitColor = Color(int.parse(habit.color.replaceAll('#', '0xFF')));

        return GestureDetector(
          onTapDown: (_) => isPressed.value = true,
          onTapUp: (_) => isPressed.value = false,
          onTapCancel: () => isPressed.value = false,
          onTap: () => controller.toggleHabit(habit),
          child: AnimatedScale(
            scale: isPressed.value ? 0.96 : 1.0,
            duration: const Duration(milliseconds: 150),
            curve: Curves.easeOutCubic,
            child: Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: isCompleted ? Colors.white.withValues(alpha: 0.6) : Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: isCompleted ? Colors.grey.withValues(alpha: 0.1) : Colors.white,
                  width: 1.5,
                ),
                boxShadow: isCompleted ? [] : [
                  BoxShadow(
                    color: AppTheme.primaryColor.withValues(alpha: 0.04),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                children: [
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    curve: Curves.easeOutBack,
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: isCompleted ? AppTheme.successColor : Colors.transparent,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: isCompleted ? AppTheme.successColor : Colors.grey.shade300,
                        width: 2,
                      ),
                    ),
                    child: isCompleted
                        ? const Icon(Icons.check, color: Colors.white, size: 20)
                            .animate().scale(delay: 50.ms, duration: 200.ms, curve: Curves.easeOutBack)
                        : null,
                  ),
              const SizedBox(width: 16),
              
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AnimatedDefaultTextStyle(
                      duration: const Duration(milliseconds: 300),
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        letterSpacing: -0.2,
                        color: isCompleted ? Colors.grey : const Color(0xFF2D2D2D),
                        decoration: isCompleted ? TextDecoration.lineThrough : null,
                      ),
                      child: Text(habit.name),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        if (controller.getStreak(habit.id) > 0) ...[
                          const Text('🔥 ', style: TextStyle(fontSize: 12)),
                          Text(
                            '${controller.getStreak(habit.id)} days',
                            style: const TextStyle(
                              fontSize: 12,
                              color: Colors.grey,
                            ),
                          ),
                        ] else ...[
                          const Text(
                            'Yesterday missed · no shame',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                        const SizedBox(width: 8),
                        Text(
                          habit.timeOfDay.capitalizeFirst!,
                          style: const TextStyle(
                            fontSize: 11,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: habitColor.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: Text(
                    habit.emoji,
                    style: const TextStyle(fontSize: 20),
                  ),
                ),
              ),
            ],
          ).animate().fadeIn(duration: 400.ms),
        )));
      }),
    );
  }
}
