import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../models/habit_model.dart';
import '../controllers/home_controller.dart';
import '../../../core/theme/app_theme.dart';

class AddHabitSheet extends StatefulWidget {
  final HabitModel? habit;
  const AddHabitSheet({super.key, this.habit});

  @override
  State<AddHabitSheet> createState() => _AddHabitSheetState();
}

class _AddHabitSheetState extends State<AddHabitSheet> {
  late TextEditingController _nameController;
  String _selectedEmoji = '💊';
  String _selectedTimeOfDay = 'morning';
  String _selectedReminderStyle = 'soft';
  bool _aiBreakdownEnabled = true;
  String _selectedColor = '#7F77DD';

  final List<String> _emojis = ['💊', '🚶', '📖', '💧', '🧘', '✍️', '🏋️', '😴', '🎯', '🌱', '🍎', '🧠'];
  final List<String> _timesOfDay = ['anytime', 'morning', 'afternoon', 'evening', 'night'];

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.habit?.name ?? '');
    if (widget.habit != null) {
      _selectedEmoji = widget.habit!.emoji;
      _selectedTimeOfDay = widget.habit!.timeOfDay;
      _selectedReminderStyle = widget.habit!.reminderStyle;
      _aiBreakdownEnabled = widget.habit!.aiBreakdownEnabled;
      _selectedColor = widget.habit!.color;
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  void _saveHabit() {
    if (_nameController.text.isEmpty) return;

    final habit = HabitModel(
      id: widget.habit?.id,
      name: _nameController.text,
      timeOfDay: _selectedTimeOfDay,
      reminderStyle: _selectedReminderStyle,
      color: _selectedColor,
      emoji: _selectedEmoji,
      aiBreakdownEnabled: _aiBreakdownEnabled,
      isActive: widget.habit?.isActive ?? true,
      habitOrder: widget.habit?.habitOrder ?? 0,
    );

    final controller = Get.find<HomeController>();
    if (widget.habit == null) {
      controller.addHabit(habit);
    } else {
      controller.updateHabit(habit);
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        top: 24,
        left: 24,
        right: 24,
      ),
      decoration: const BoxDecoration(
        color: AppTheme.backgroundColor,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  widget.habit == null ? 'New Habit' : 'Edit Habit',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
                ),
                if (widget.habit != null)
                  IconButton(
                    icon: const Icon(Icons.delete_outline, color: Colors.grey),
                    onPressed: () {
                      Get.find<HomeController>().deleteHabit(widget.habit!.id);
                      Navigator.pop(context);
                    },
                  ),
              ],
            ),
            const SizedBox(height: 24),
            TextField(
              controller: _nameController,
              autofocus: true,
              maxLength: 50,
              decoration: InputDecoration(
                hintText: 'e.g. Take medication',
                hintStyle: const TextStyle(color: Colors.grey),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Colors.white,
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: const BorderSide(color: AppTheme.primaryColor, width: 2),
                ),
              ),
              onChanged: (val) => setState(() {}),
            ),
            const SizedBox(height: 16),
            const Text('Emoji', style: TextStyle(fontWeight: FontWeight.w500)),
            const SizedBox(height: 12),
            SizedBox(
              height: 50,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: _emojis.length,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () => setState(() => _selectedEmoji = _emojis[index]),
                    child: Container(
                      width: 44,
                      height: 44,
                      margin: const EdgeInsets.only(right: 8),
                      decoration: BoxDecoration(
                        color: _selectedEmoji == _emojis[index] ? AppTheme.primaryColor.withValues(alpha: 0.1) : Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: _selectedEmoji == _emojis[index] ? AppTheme.primaryColor : Colors.transparent,
                        ),
                      ),
                      alignment: Alignment.center,
                      child: Text(_emojis[index], style: const TextStyle(fontSize: 20)),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 24),
            const Text('Time of Day', style: TextStyle(fontWeight: FontWeight.w500)),
            const SizedBox(height: 12),
            Row(
              children: _timesOfDay.map((time) {
                final isSelected = _selectedTimeOfDay == time;
                return Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _selectedTimeOfDay = time),
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(
                        color: isSelected ? AppTheme.primaryColor : Colors.white,
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(
                          color: isSelected ? AppTheme.primaryColor : Colors.grey.shade300,
                        ),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        time[0].toUpperCase() + time.substring(1),
                        style: TextStyle(
                          color: isSelected ? Colors.white : Colors.black87,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('AI Breakdown', style: TextStyle(fontWeight: FontWeight.w500)),
                    Text('Break tasks into micro-steps', style: TextStyle(color: Colors.grey, fontSize: 12)),
                  ],
                ),
                Switch(
                  value: _aiBreakdownEnabled,
                  onChanged: (val) => setState(() => _aiBreakdownEnabled = val),
                  activeTrackColor: AppTheme.primaryColor.withValues(alpha: 0.5),
                  activeThumbColor: AppTheme.primaryColor,
                ),
              ],
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: _nameController.text.isEmpty ? null : _saveHabit,
              child: Text(widget.habit == null ? 'Save habit' : 'Update habit'),
            ),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
}
