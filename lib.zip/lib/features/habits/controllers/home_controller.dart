import 'dart:async';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/habit_model.dart';
import '../models/completion_model.dart';
import '../repositories/habit_repository.dart';
import '../widgets/dopamine_celebration.dart';

class HomeController extends GetxController {
  final HabitRepository _repository = HabitRepository();
  
  final habits = <HabitModel>[].obs;
  final completions = <String, bool>{}.obs;
  final streaks = <String, int>{}.obs;
  final isLoading = true.obs;
  final todayProgress = 0.0.obs;
  final userName = 'Friend'.obs;
  final dopaminePoints = 0.obs;

  Timer? _paralysisTimer;
  final showParalysisBanner = false.obs;
  final _lastActivityTime = DateTime.now().obs;

  @override
  void onInit() {
    super.onInit();
    _loadUserData();
    refreshData();
    _initParalysisDetection();
  }

  @override
  void onClose() {
    _paralysisTimer?.cancel();
    super.onClose();
  }

  Future<void> _loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    userName.value = prefs.getString('user_name') ?? 'Friend';
    dopaminePoints.value = prefs.getInt('dopamine_points') ?? 0;
  }

  Future<void> refreshData() async {
    isLoading.value = true;
    final habitsResult = await _repository.getAllHabits();
    final completionsResult = await _repository.getCompletionsForDate(DateTime.now());

    if (habitsResult.isSuccess) {
      habits.assignAll(habitsResult.data!);
    }

    if (completionsResult.isSuccess) {
      completions.clear();
      for (var c in completionsResult.data!) {
        completions[c.habitId] = true;
      }
    }

    _calculateProgress();
    await _loadStreaks();
    isLoading.value = false;
  }

  /// Loads streaks for all habits in parallel and caches them reactively,
  /// so list items never trigger per-rebuild database queries.
  Future<void> _loadStreaks() async {
    final entries = await Future.wait(
      habits.map((h) async => MapEntry(h.id, await _repository.getStreakForHabit(h.id))),
    );
    streaks.assignAll(Map.fromEntries(entries));
  }

  void _calculateProgress() {
    if (habits.isEmpty) {
      todayProgress.value = 0.0;
      return;
    }
    final completedCount = habits.where((h) => completions[h.id] == true).length;
    todayProgress.value = completedCount / habits.length;
  }

  bool isCompleted(String habitId) {
    return completions[habitId] == true;
  }

  int getStreak(String habitId) {
    return streaks[habitId] ?? 0;
  }

  Future<void> addHabit(HabitModel habit) async {
    final result = await _repository.createHabit(habit);
    if (result.isSuccess) {
      habits.add(habit);
      _calculateProgress();
    } else {
      Get.snackbar('Error', 'Failed to create habit', snackPosition: SnackPosition.BOTTOM);
    }
  }

  Future<void> updateHabit(HabitModel habit) async {
    final result = await _repository.updateHabit(habit);
    if (result.isSuccess) {
      final index = habits.indexWhere((h) => h.id == habit.id);
      if (index >= 0) {
        habits[index] = habit;
      }
    } else {
      Get.snackbar('Error', 'Failed to update habit', snackPosition: SnackPosition.BOTTOM);
    }
  }

  Future<void> deleteHabit(String id) async {
    final result = await _repository.deleteHabit(id);
    if (result.isSuccess) {
      habits.removeWhere((h) => h.id == id);
      completions.remove(id);
      streaks.remove(id);
      _calculateProgress();
    } else {
      Get.snackbar('Error', 'Failed to delete habit', snackPosition: SnackPosition.BOTTOM);
    }
  }

  final _lastToggle = <String, DateTime>{};

  Future<void> toggleHabit(HabitModel habit) async {
    _resetParalysisTimer();

    if (completions[habit.id] == true) return;

    // Debounce rapid repeat taps on the same habit (spec: 500ms).
    final now = DateTime.now();
    final last = _lastToggle[habit.id];
    if (last != null && now.difference(last).inMilliseconds < 500) return;
    _lastToggle[habit.id] = now;

    // Optimistic UI update first (instant feedback before DB write).
    completions[habit.id] = true;
    _calculateProgress();
    HapticFeedback.lightImpact();

    dopaminePoints.value += 10;
    if (todayProgress.value >= 1.0) dopaminePoints.value += 25;

    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('dopamine_points', dopaminePoints.value);

    final completion = CompletionModel(habitId: habit.id);
    final result = await _repository.completeHabit(completion);

    if (!result.isSuccess) {
      // Revert optimistic update on failure.
      completions[habit.id] = false;
      dopaminePoints.value -= 10;
      _calculateProgress();
      Get.snackbar('Error', 'Failed to save completion', snackPosition: SnackPosition.BOTTOM);
      return;
    }

    // Update cached streak for this habit only (no full reload).
    final newStreak = await _repository.getStreakForHabit(habit.id);
    streaks[habit.id] = newStreak;
    
    // Trigger dopamine celebration
    DopamineCelebration.show(newStreak);
  }

  void addPoints(int points) {
    dopaminePoints.value += points;
    SharedPreferences.getInstance().then((prefs) {
      prefs.setInt('dopamine_points', dopaminePoints.value);
    });
  }

  void _initParalysisDetection() {
    _paralysisTimer = Timer.periodic(const Duration(minutes: 1), (timer) {
      final now = DateTime.now();
      if (now.hour >= 8 && now.hour <= 22) {
        if (now.difference(_lastActivityTime.value).inMinutes >= 35) {
          showParalysisBanner.value = true;
        }
      }
    });
  }

  void _resetParalysisTimer() {
    _lastActivityTime.value = DateTime.now();
    showParalysisBanner.value = false;
  }

  String get greeting {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  }
}
