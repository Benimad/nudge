import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:package_info_plus/package_info_plus.dart';
import '../../../core/theme/app_theme.dart';
import '../../habits/controllers/home_controller.dart';
import '../services/subscription_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final SubscriptionService _subscriptionService = SubscriptionService();
  bool _isPro = false;
  bool _isLoadingPro = true;
  String _appVersion = '1.0.0';
  String _userName = 'Friend';
  String _brainType = 'Not set';

  // Toggle states
  bool _sensorySafe = false;
  bool _noRedBadges = true;
  bool _highContrast = false;
  bool _overwhelmMode = false;
  bool _largeText = false;
  bool _onDeviceAi = false;
  bool _shareAnonymous = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    final isPro = await _subscriptionService.isPro();
    final packageInfo = await PackageInfo.fromPlatform();

    if (mounted) {
      setState(() {
        _isPro = isPro;
        _isLoadingPro = false;
        _appVersion = packageInfo.version;
        _userName = prefs.getString('user_name') ?? 'Friend';
        _brainType = prefs.getString('brain_type') ?? 'Not set';
        _sensorySafe = prefs.getBool('sensory_safe_ui') ?? false;
        _noRedBadges = prefs.getBool('no_red_badges') ?? true;
        _highContrast = prefs.getBool('high_contrast') ?? false;
        _overwhelmMode = prefs.getBool('overwhelm_mode') ?? false;
        _largeText = prefs.getBool('large_text') ?? false;
        _onDeviceAi = prefs.getBool('on_device_ai') ?? false;
        _shareAnonymous = prefs.getBool('share_anonymous') ?? true;
      });
    }
  }

  Future<void> _saveToggle(String key, bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(key, value);
  }

  Future<void> _editUserName() async {
    final controller = TextEditingController(text: _userName);
    final result = await Get.defaultDialog<String>(
      title: 'Edit name',
      titleStyle: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w500),
      content: TextField(
        controller: controller,
        decoration: InputDecoration(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          filled: true,
          fillColor: const Color(0xFFFAFAF9),
        ),
      ),
      confirm: ElevatedButton(
        onPressed: () => Get.back(result: controller.text),
        style: ElevatedButton.styleFrom(
          backgroundColor: AppTheme.primaryColor,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        ),
        child: const Text('Save', style: TextStyle(fontFamily: 'Inter')),
      ),
      cancel: TextButton(
        onPressed: () => Get.back(),
        child: const Text('Cancel', style: TextStyle(color: Colors.grey, fontFamily: 'Inter')),
      ),
    );

    if (result != null && result.isNotEmpty) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('user_name', result);
      setState(() => _userName = result);
      Get.find<HomeController>().userName.value = result;
    }
  }

  Future<void> _editBrainType() async {
    final types = ['ADHD', 'Autism', 'Anxiety', 'Neurotypical', 'Not sure'];
    final result = await Get.defaultDialog<String>(
      title: 'Brain type',
      titleStyle: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w500),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: types.map((type) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: GestureDetector(
              onTap: () => Get.back(result: type),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                decoration: BoxDecoration(
                  color: _brainType == type ? const Color(0xFFEEEDFE) : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _brainType == type ? AppTheme.primaryColor : Colors.grey.shade200,
                  ),
                ),
                child: Text(
                  type,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: _brainType == type ? AppTheme.primaryColor : const Color(0xFF2D2D2D),
                    fontFamily: 'Inter',
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
      confirm: const SizedBox.shrink(),
      cancel: TextButton(
        onPressed: () => Get.back(),
        child: const Text('Cancel', style: TextStyle(color: Colors.grey, fontFamily: 'Inter')),
      ),
    );

    if (result != null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('brain_type', result);
      setState(() => _brainType = result);
    }
  }

  Future<void> _exportData() async {
    // Generate JSON file with all user data
    final prefs = await SharedPreferences.getInstance();
    final data = {
      'user_name': _userName,
      'brain_type': _brainType,
      'goals': prefs.getString('user_goals'),
      'dopamine_points': prefs.getInt('dopamine_points') ?? 0,
      'settings': {
        'sensory_safe_ui': _sensorySafe,
        'no_red_badges': _noRedBadges,
        'high_contrast': _highContrast,
        'overwhelm_mode': _overwhelmMode,
        'large_text': _largeText,
        'on_device_ai': _onDeviceAi,
        'share_anonymous': _shareAnonymous,
      },
      'exported_at': DateTime.now().toIso8601String(),
    };

    const JsonEncoder.withIndent('  ').convert(data);
    
    // In production, save to file and share
    Get.snackbar(
      'Data exported',
      'Your data has been prepared for export.',
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: const Color(0xFF1D9E75),
      colorText: Colors.white,
    );
  }

  Future<void> _deleteAllData() async {
    final confirmed = await Get.defaultDialog<bool>(
      title: 'Delete all data?',
      titleStyle: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w500),
      middleText: 'This will permanently delete all your habits and history. This cannot be undone.',
      middleTextStyle: const TextStyle(fontFamily: 'Inter'),
      confirm: ElevatedButton(
        onPressed: () => Get.back(result: true),
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.grey,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        ),
        child: const Text('Delete', style: TextStyle(fontFamily: 'Inter')),
      ),
      cancel: TextButton(
        onPressed: () => Get.back(result: false),
        child: const Text('Cancel', style: TextStyle(color: Color(0xFF7F77DD), fontFamily: 'Inter')),
      ),
    );

    if (confirmed == true) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear();
      Get.offAllNamed('/onboarding/welcome');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAF9),
      appBar: AppBar(
        title: const Text(
          'Settings',
          style: TextStyle(fontWeight: FontWeight.w500, fontFamily: 'Inter'),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          // Section 1 - Profile
          _buildSectionHeader('Profile'),
          _buildProfileCard(),
          const SizedBox(height: 24),

          // Section 2 - ADHD Settings
          _buildSectionHeader('ADHD Settings'),
          _buildAdhdSettings(),
          const SizedBox(height: 24),

          // Section 3 - Reminders
          _buildSectionHeader('Reminders'),
          _buildReminderSettings(),
          const SizedBox(height: 24),

          // Section 4 - Privacy
          _buildSectionHeader('Privacy'),
          _buildPrivacySettings(),
          const SizedBox(height: 24),

          // Section 5 - About
          _buildSectionHeader('About'),
          _buildAboutSection(),

          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w500,
          color: Colors.grey,
          fontFamily: 'Inter',
        ),
      ),
    );
  }

  Widget _buildProfileCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          // User name (editable)
          GestureDetector(
            onTap: _editUserName,
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: const BoxDecoration(
                    color: Color(0xFFEEEDFE),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.person, color: Color(0xFF7F77DD), size: 24),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _userName,
                        style: const TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 16,
                          fontFamily: 'Inter',
                          color: Color(0xFF2D2D2D),
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Tap to edit',
                        style: TextStyle(
                          fontSize: 11,
                          color: Colors.grey[400],
                          fontFamily: 'Inter',
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.edit_outlined, color: Colors.grey, size: 18),
              ],
            ),
          ),
          const Divider(height: 24),

          // Brain type (editable)
          GestureDetector(
            onTap: _editBrainType,
            child: Row(
              children: [
                const Icon(Icons.psychology_outlined, color: Color(0xFF7F77DD), size: 20),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Brain type',
                        style: TextStyle(
                          fontSize: 13,
                          color: Colors.grey,
                          fontFamily: 'Inter',
                        ),
                      ),
                      Text(
                        _brainType,
                        style: const TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 14,
                          fontFamily: 'Inter',
                          color: Color(0xFF2D2D2D),
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right, color: Colors.grey, size: 20),
              ],
            ),
          ),
          const Divider(height: 24),

          // Subscription status
          Row(
            children: [
              const Icon(Icons.workspace_premium_outlined, color: Color(0xFFEF9F27), size: 20),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Subscription',
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey,
                        fontFamily: 'Inter',
                      ),
                    ),
                    if (_isLoadingPro)
                      const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF7F77DD)),
                      )
                    else
                      Text(
                        _isPro ? 'Nudge Pro' : 'Free',
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 14,
                          fontFamily: 'Inter',
                          color: _isPro ? const Color(0xFF1D9E75) : const Color(0xFF2D2D2D),
                        ),
                      ),
                  ],
                ),
              ),
              if (!_isPro)
                GestureDetector(
                  onTap: () => Get.toNamed('/paywall'),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFFEEEDFE),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Text(
                      'Upgrade',
                      style: TextStyle(
                        color: Color(0xFF7F77DD),
                        fontWeight: FontWeight.w500,
                        fontSize: 12,
                        fontFamily: 'Inter',
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAdhdSettings() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          _buildToggleRow(
            'Sensory-safe UI',
            'Disables all animations',
            _sensorySafe,
            (val) => setState(() { _sensorySafe = val; _saveToggle('sensory_safe_ui', val); }),
          ),
          const Divider(height: 24),
          _buildToggleRow(
            'No red badges',
            'On app icon',
            _noRedBadges,
            (val) => setState(() { _noRedBadges = val; _saveToggle('no_red_badges', val); }),
          ),
          const Divider(height: 24),
          _buildToggleRow(
            'High contrast mode',
            'Better visibility',
            _highContrast,
            (val) => setState(() { _highContrast = val; _saveToggle('high_contrast', val); }),
          ),
          const Divider(height: 24),
          _buildToggleRow(
            'Overwhelm mode',
            'Show only 1 task at a time',
            _overwhelmMode,
            (val) => setState(() { _overwhelmMode = val; _saveToggle('overwhelm_mode', val); }),
          ),
          const Divider(height: 24),
          _buildToggleRow(
            'Large text mode',
            'Bigger fonts everywhere',
            _largeText,
            (val) => setState(() { _largeText = val; _saveToggle('large_text', val); }),
          ),
        ],
      ),
    );
  }

  Widget _buildReminderSettings() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          _buildInfoRow('Morning reminder', '8:00 AM'),
          const Divider(height: 24),
          _buildInfoRow('Evening review', '8:00 PM'),
          const Divider(height: 24),
          _buildInfoRow('Reminder style', 'Soft nudge'),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () {
                Get.snackbar(
                  'Notification',
                  'Test notification sent!',
                  snackPosition: SnackPosition.BOTTOM,
                  backgroundColor: const Color(0xFF1D9E75),
                  colorText: Colors.white,
                );
              },
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Color(0xFF7F77DD)),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
              child: const Text(
                'Test notification',
                style: TextStyle(color: Color(0xFF7F77DD), fontFamily: 'Inter'),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPrivacySettings() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          _buildToggleRow(
            'On-device AI only',
            'No cloud processing',
            _onDeviceAi,
            (val) => setState(() { _onDeviceAi = val; _saveToggle('on_device_ai', val); }),
          ),
          const Divider(height: 24),
          _buildToggleRow(
            'Share anonymous data',
            'Help improve Nudge',
            _shareAnonymous,
            (val) => setState(() { _shareAnonymous = val; _saveToggle('share_anonymous', val); }),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: _exportData,
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Colors.grey),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
              child: const Text(
                'Export all my data',
                style: TextStyle(color: Colors.grey, fontFamily: 'Inter'),
              ),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: _deleteAllData,
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Colors.grey),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
              child: const Text(
                'Delete all data',
                style: TextStyle(color: Colors.grey, fontFamily: 'Inter'),
              ),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () {
                Get.snackbar(
                  'Coming soon',
                  'PDF report generation will be available in a future update.',
                  snackPosition: SnackPosition.BOTTOM,
                );
              },
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Colors.grey),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
              child: const Text(
                'Share with therapist',
                style: TextStyle(color: Colors.grey, fontFamily: 'Inter'),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAboutSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          _buildInfoRow('Version', _appVersion),
          const Divider(height: 24),
          _buildClickableRow('Rate on Play Store', () {
            // Open Play Store
          }),
          const Divider(height: 24),
          _buildClickableRow('Send feedback', () {
            // Open email/feedback form
          }),
          const Divider(height: 24),
          _buildClickableRow('Privacy policy', () {
            // Open URL
          }),
          const Divider(height: 24),
          _buildClickableRow('Terms of service', () {
            // Open URL
          }),
        ],
      ),
    );
  }

  Widget _buildToggleRow(String title, String subtitle, bool value, ValueChanged<bool> onChanged) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                  fontFamily: 'Inter',
                  color: Color(0xFF2D2D2D),
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: const TextStyle(fontSize: 12, color: Colors.grey, fontFamily: 'Inter'),
              ),
            ],
          ),
        ),
        Switch(
          value: value,
          onChanged: onChanged,
          activeTrackColor: AppTheme.primaryColor.withValues(alpha: 0.5),
          activeThumbColor: AppTheme.primaryColor,
        ),
      ],
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 14,
            fontFamily: 'Inter',
            color: Color(0xFF2D2D2D),
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            color: Colors.grey,
            fontFamily: 'Inter',
          ),
        ),
      ],
    );
  }

  Widget _buildClickableRow(String title, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontWeight: FontWeight.w500,
              fontSize: 14,
              fontFamily: 'Inter',
              color: Color(0xFF2D2D2D),
            ),
          ),
          const Icon(Icons.chevron_right, color: Colors.grey, size: 20),
        ],
      ),
    );
  }
}