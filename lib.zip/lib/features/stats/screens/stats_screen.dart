import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../habits/controllers/home_controller.dart';
import '../../habits/repositories/habit_repository.dart';
import '../../../core/theme/app_theme.dart';

class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<HomeController>();
    final repository = HabitRepository();

    return Scaffold(
      backgroundColor: const Color(0xFFFAFAF9),
      appBar: AppBar(
        title: const Text(
          'Statistics',
          style: TextStyle(fontWeight: FontWeight.w500, fontFamily: 'Inter'),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Metric Cards Row
            _buildMetricCards(repository),
            const SizedBox(height: 24),

            // Weekly Bar Chart
            const Text(
              'This Week',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w500,
                fontFamily: 'Inter',
                color: Color(0xFF2D2D2D),
              ),
            ),
            const SizedBox(height: 16),
            _buildWeeklyChart(repository),
            const SizedBox(height: 24),

            // Monthly Heatmap
            const Text(
              'Monthly Overview',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w500,
                fontFamily: 'Inter',
                color: Color(0xFF2D2D2D),
              ),
            ),
            const SizedBox(height: 16),
            _buildMonthlyHeatmap(repository),
            const SizedBox(height: 24),

            // Streak Display
            const Text(
              'Current Streaks',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w500,
                fontFamily: 'Inter',
                color: Color(0xFF2D2D2D),
              ),
            ),
            const SizedBox(height: 16),
            _buildStreakList(controller, repository),
            const SizedBox(height: 24),

            // AI Weekly Insight
            _buildAiInsightCard(),
          ],
        ),
      ),
    );
  }

  Widget _buildMetricCards(HabitRepository repository) {
    return FutureBuilder(
      future: Future.wait([
        repository.getTotalWins(),
        _getBestStreak(repository),
        _getWeekCompletion(repository),
      ]),
      builder: (context, AsyncSnapshot<List<dynamic>> snapshot) {
        final totalWins = snapshot.data?[0] ?? 0;
        final bestStreak = snapshot.data?[1] ?? 0;
        final weekCompletion = snapshot.data?[2] ?? 0.0;

        return Row(
          children: [
            _buildMetricCard('This week', '${(weekCompletion * 100).toInt()}%', Icons.trending_up),
            const SizedBox(width: 12),
            _buildMetricCard('Best streak', '$bestStreak days', Icons.local_fire_department),
            const SizedBox(width: 12),
            _buildMetricCard('Total wins', '$totalWins', Icons.emoji_events),
          ],
        );
      },
    );
  }

  Widget _buildMetricCard(String label, String value, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.02),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: AppTheme.primaryColor, size: 20),
            const SizedBox(height: 8),
            Text(
              value,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w500,
                fontFamily: 'Inter',
                color: Color(0xFF2D2D2D),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: const TextStyle(
                fontSize: 11,
                color: Colors.grey,
                fontFamily: 'Inter',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWeeklyChart(HabitRepository repository) {
    return Container(
      height: 200,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.02),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: FutureBuilder(
        future: _getWeekData(repository),
        builder: (context, AsyncSnapshot<List<double>> snapshot) {
          final data = snapshot.data ?? List.filled(7, 0.0);
          final today = DateTime.now().weekday - 1;

          return BarChart(
            BarChartData(
              alignment: BarChartAlignment.spaceAround,
              maxY: 1.0,
              minY: 0,
              barTouchData: BarTouchData(
                enabled: true,
                touchTooltipData: BarTouchTooltipData(
                  getTooltipItem: (group, groupIndex, rod, rodIndex) {
                    final days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                    return BarTooltipItem(
                      '${(rod.toY * 100).toInt()}% on ${days[groupIndex]}',
                      const TextStyle(color: Colors.white, fontSize: 12),
                    );
                  },
                ),
              ),
              titlesData: FlTitlesData(
                show: true,
                topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    getTitlesWidget: (value, meta) {
                      final days = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
                      return Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Text(
                          days[value.toInt()],
                          style: TextStyle(
                            fontSize: 12,
                            color: value.toInt() == today ? AppTheme.primaryColor : Colors.grey,
                            fontWeight: value.toInt() == today ? FontWeight.w500 : FontWeight.w400,
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
              gridData: const FlGridData(show: false),
              borderData: FlBorderData(show: false),
              barGroups: List.generate(7, (index) {
                final isToday = index == today;
                return BarChartGroupData(
                  x: index,
                  barRods: [
                    BarChartRodData(
                      toY: data[index],
                      color: isToday ? AppTheme.primaryColor : AppTheme.primaryColor.withValues(alpha: 0.4),
                      width: 16,
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
                    ),
                  ],
                );
              }),
            ),
          );
        },
      ),
    );
  }

  Widget _buildMonthlyHeatmap(HabitRepository repository) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.02),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: FutureBuilder(
        future: _getMonthData(repository),
        builder: (context, AsyncSnapshot<Map<int, double>> snapshot) {
          final data = snapshot.data ?? {};
          final now = DateTime.now();
          final daysInMonth = DateTime(now.year, now.month + 1, 0).day;
          final firstWeekday = DateTime(now.year, now.month, 1).weekday;

          return Column(
            children: [
              // Day headers
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: ['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((d) {
                  return SizedBox(
                    width: 28,
                    child: Text(
                      d,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 10, color: Colors.grey),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 8),
              // Grid
              Wrap(
                spacing: 4,
                runSpacing: 4,
                children: List.generate(42, (index) {
                  final day = index - firstWeekday + 2;
                  if (day < 1 || day > daysInMonth) {
                    return const SizedBox(width: 28, height: 28);
                  }
                  final rate = data[day] ?? 0.0;
                  return GestureDetector(
                    onTap: () {
                      // Show tooltip with details
                    },
                    child: Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        color: _getHeatColor(rate),
                        shape: BoxShape.circle,
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        '$day',
                        style: TextStyle(
                          fontSize: 10,
                          color: rate > 0.5 ? Colors.white : Colors.grey,
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ],
          );
        },
      ),
    );
  }

  Color _getHeatColor(double rate) {
    if (rate == 0) return Colors.grey.shade100;
    if (rate < 0.5) return AppTheme.primaryColor.withValues(alpha: 0.2);
    if (rate < 0.8) return AppTheme.primaryColor.withValues(alpha: 0.5);
    return AppTheme.primaryColor;
  }

  Widget _buildStreakList(HomeController controller, HabitRepository repository) {
    return FutureBuilder(
      future: _getStreaksWithHabits(controller, repository),
      builder: (context, AsyncSnapshot<List<MapEntry<String, int>>> snapshot) {
        if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Center(
              child: Text(
                'No habits yet. Add one to start tracking!',
                style: TextStyle(color: Colors.grey, fontFamily: 'Inter'),
              ),
            ),
          );
        }

        return Column(
          children: snapshot.data!.map((entry) {
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Text('🔥 ', style: TextStyle(fontSize: 16)),
                  Expanded(
                    child: Text(
                      entry.key,
                      style: const TextStyle(
                        fontWeight: FontWeight.w500,
                        fontFamily: 'Inter',
                        color: Color(0xFF2D2D2D),
                      ),
                    ),
                  ),
                  Text(
                    '${entry.value} days',
                    style: const TextStyle(
                      color: Colors.grey,
                      fontFamily: 'Inter',
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
        );
      },
    );
  }

  Widget _buildAiInsightCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: const Border(
          left: BorderSide(color: Color(0xFF7F77DD), width: 4),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.02),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.auto_awesome, color: Color(0xFF7F77DD), size: 20),
              const SizedBox(width: 8),
              const Text(
                'AI Weekly Insight',
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  fontFamily: 'Inter',
                  color: Color(0xFF2D2D2D),
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: () {
                  // Refresh insight
                },
                child: const Icon(Icons.refresh, color: Colors.grey, size: 18),
              ),
            ],
          ),
          const SizedBox(height: 12),
          const Text(
            'Keep tracking your habits to receive personalized insights about your patterns and progress.',
            style: TextStyle(
              fontSize: 13,
              color: Colors.grey,
              fontFamily: 'Inter',
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  // Helper methods
  Future<int> _getBestStreak(HabitRepository repository) async {
    final habitsResult = await repository.getAllHabits();
    if (!habitsResult.isSuccess || habitsResult.data!.isEmpty) return 0;
    int best = 0;
    for (final habit in habitsResult.data!) {
      final streak = await repository.getStreakForHabit(habit.id);
      if (streak > best) best = streak;
    }
    return best;
  }

  Future<double> _getWeekCompletion(HabitRepository repository) async {
    final now = DateTime.now();
    final monday = now.subtract(Duration(days: now.weekday - 1));
    double total = 0;
    for (int i = 0; i < 7; i++) {
      total += await repository.getCompletionRateForDate(monday.add(Duration(days: i)));
    }
    return total / 7;
  }

  Future<List<double>> _getWeekData(HabitRepository repository) async {
    final now = DateTime.now();
    final monday = now.subtract(Duration(days: now.weekday - 1));
    final data = <double>[];
    for (int i = 0; i < 7; i++) {
      data.add(await repository.getCompletionRateForDate(monday.add(Duration(days: i))));
    }
    return data;
  }

  Future<Map<int, double>> _getMonthData(HabitRepository repository) async {
    final now = DateTime.now();
    final daysInMonth = DateTime(now.year, now.month + 1, 0).day;
    final data = <int, double>{};
    for (int day = 1; day <= daysInMonth; day++) {
      final date = DateTime(now.year, now.month, day);
      data[day] = await repository.getCompletionRateForDate(date);
    }
    return data;
  }

  Future<List<MapEntry<String, int>>> _getStreaksWithHabits(
    HomeController controller, HabitRepository repository) async {
    final habitsResult = await repository.getAllHabits();
    if (!habitsResult.isSuccess) return [];
    final entries = <MapEntry<String, int>>[];
    for (final habit in habitsResult.data!) {
      final streak = await repository.getStreakForHabit(habit.id);
      entries.add(MapEntry(habit.name, streak));
    }
    entries.sort((a, b) => b.value.compareTo(a.value));
    return entries;
  }
}
